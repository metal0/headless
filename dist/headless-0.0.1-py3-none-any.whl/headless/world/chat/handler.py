class ChatHandler:
	pass


class GuildRoster:
	def __init__(self, member_data):
		self._member_data = member_data

	# @property
	# def guid(self):
	# 	return self._
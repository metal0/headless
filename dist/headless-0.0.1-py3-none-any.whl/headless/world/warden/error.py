from ..errors import WorldError

class ChallengeResponseNotFound(WorldError):
    pass
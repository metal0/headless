# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['headless',
 'headless.auth',
 'headless.utility',
 'headless.world',
 'headless.world.chat',
 'headless.world.entities',
 'headless.world.guild',
 'headless.world.warden']

package_data = \
{'': ['*']}

install_requires = \
['construct>=2,<3',
 'cryptography>=36,<37',
 'loguru>=0.6,<0.7',
 'pyee>=9.0,<10.0',
 'trio-socks @ git+https://github.com/Ostoic/trio-socks@0.1.1',
 'trio>=0.20,<0.21']

setup_kwargs = {
    'name': 'headless',
    'version': '0.0.1',
    'description': '',
    'long_description': None,
    'author': 'Shaun Ostoic',
    'author_email': 'ostoic@uwindsor.ca',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)

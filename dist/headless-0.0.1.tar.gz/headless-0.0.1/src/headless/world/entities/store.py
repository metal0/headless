# import esper
#
# class EntityStore:
# 	def __init__(self):
# 		self._store = esper.World()





class WorldError(Exception):
	pass
class AuctionHouse:
	pass

class Auction:
	pass
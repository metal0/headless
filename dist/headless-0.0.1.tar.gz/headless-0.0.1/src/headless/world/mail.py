
class Mailbox:
	pass

class Mail:
	pass

